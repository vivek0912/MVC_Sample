﻿import { Component } from "@angular/core";

@Component({
    template: `<img src="../../images/users.png" style="text-align:center"/>`
})

export class HomeComponent{
}