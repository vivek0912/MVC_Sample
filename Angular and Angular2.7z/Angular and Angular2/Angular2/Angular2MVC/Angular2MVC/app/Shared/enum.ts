﻿export enum DBOperation {
    create = 1,
    update = 2,
    delete =3
}