### Angular2 Starter Plunker - Typescript

A simple plunker demonstrating Angular2 usage

Used in https://tests4geeks.com/tutorials/angular-2-tutorial/