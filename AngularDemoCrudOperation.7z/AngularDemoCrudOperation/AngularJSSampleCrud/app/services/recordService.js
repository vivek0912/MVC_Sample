﻿/// <reference path="flightService.js" />
(function (app) {

    var Records =
                  [  
                      {
                          Id : 1,
                          FirstName: "vivek",
                          LastName: "vishal",
                          Company: "agility",
                          JobTitle: "software engineer",
                          BusinessPhone: "7207101627",
                          HomePhone: "7207101627",
                          MobilePhone: "7207101627",
                          FaxNumber: "0402547898",
                          Street: "sr nagar ameerpet",
                          City: "Hyderabad",
                          State: "Telangana",
                          Country: "india",
                          Email: "vivek@gmail.com",
                          WebPage: "www.vivek.com",
                          Notes: " "                          
                      },
                      {
                           Id : 2,
                           FirstName: "vishal ",
                           LastName: "kumar",
                           Company: "abc.com",
                           JobTitle: "Software Developer",
                           BusinessPhone: "7878787878",
                           HomePhone: "8989898989",
                           MobilePhone: "7878787878",
                           FaxNumber: "0402547878",
                           Street: "ameerpet",
                           City: "hyderabad",
                           State: "Telangana",
                           Country: "India",
                           Email: "vishal@gmail.com",
                           WebPage: "www.abc.com",
                           Notes: " "
                       },
                        {
                            Id: 3,
                            FirstName: "vivek",
                            LastName: "kumar",
                            Company: "AES",
                            JobTitle: "Web Developer",
                            BusinessPhone: "5478754787",
                            HomePhone: "987897899",
                            MobilePhone: "123457897",
                            FaxNumber: "0402457845",
                            Street: "srinivasa nagar",
                            City: "hyderabad",
                            State: "Telangana",
                            Country: "India",
                            Email: "vivek09@gmail.com",
                            WebPage: "AES.com",
                            Notes: " "
                        },
                  ];


    var recordService = function () {
       
        var recordFactory = {};

        recordFactory.getRecord = function (index) {
            var returnRecord = [];
            if (recordFactory.isOverflow(index))
            {
                index = 0;
            }
            returnRecord.push(Records[index]);
            return returnRecord;
        };

        recordFactory.isOverflow = function (index){

            return (Records.length <= index)
        };

        recordFactory.addRecord = function (index) {
            var returnRecord = [];
            var newIndex = Records.length + 1;
            Records.push(recordFactory.newItem(newIndex));
            returnRecord.push(Records[Records.length -1]);
            return (returnRecord)
        };

        recordFactory.deleteRecord = function (index) {
            var returnRecord = [];

            Records.splice(index,1);
            if (Records.length <= index)
           {
                index = Records.length -1;
           }
            returnRecord.push(Records[index]);
            return (returnRecord)
        };

        recordFactory.newItem = function (index) {

            var newItem = {

                Id: index,
                FirstName: "",
                LastName: "",
                Company: "",
                JobTitle: "",
                BusinessPhone: "",
                HomePhone: "",
                MobilePhone: "",
                FaxNumber: "",
                Street: "",
                City: "",
                State: "",
                Country: "",
                Email: "",
                WebPage: "",
                Notes: ""
            }
            return newItem;

        }

        return recordFactory;
    };

    app.factory("recordService", recordService);

}(angular.module("demoApp")));