# Stratis transfer {#Stratis-transfer}
In Stratis, everything is designed to make sure that the transactions go through. In this chapter we are going to introduce the basic concepts of Stratis by guiding you through a creation of simple Stratis transaction "by hand".  
Later we are going to show you a higher level framework for building transactions.  
