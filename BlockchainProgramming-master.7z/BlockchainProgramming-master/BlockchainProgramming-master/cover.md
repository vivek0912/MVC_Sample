
![](assets/bitcoin.png)

# Programming The Blockchain in C**\#**
_Authored by Nicolas Dorier  
Creator of NStratis, The .NET Stratis Framework_

_Co-authored with Bill Strait  
Founder of Billd Labs_

_And nopara73  
Just a geek_
