# Case studies {#implementations} 

In this chapter you will see how existing implementations are made on top of NStratis.  
You will be guided through the code and the design decisions the developer had to make.  
This section is more practical. What you learn here will come handy when you face similar challenges the developers of specific implementations has already faced.
