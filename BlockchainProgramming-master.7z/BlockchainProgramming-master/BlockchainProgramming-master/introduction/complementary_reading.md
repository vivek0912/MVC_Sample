## Complementary Reading {#complementary-reading}

Here is some literature that you can use to complete this book:

*   [Mastering Bitcoin of Andreas M. Antonopoulos](https://github.com/bitcoinbook/bitcoinbook)
*   [The Bitcoin Developer’s Reference Guide](https://bitcoin.org/en/developer-guide)
*   [Nicolas Dorier’s articles on CodeProject](http://www.codeproject.com/script/Articles/MemberArticles.aspx?amid=6354608)
*   [nopara73's articles on CodeProject](http://www.codeproject.com/script/Articles/MemberArticles.aspx?amid=10170217)