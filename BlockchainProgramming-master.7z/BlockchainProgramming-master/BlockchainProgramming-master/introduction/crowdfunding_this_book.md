## Crowdfunding this book {#crowdfunding-this-book}

If we want to continue to make great stuff for you we need to buy pizza, sushi and coffee. It is our responsibility to get enough coins for that. Also, we are too lazy to keep writing a whole book without hearing your feedback.  
**Bitcoin address:** [1KF8kUVHK42XzgcmJF4Lxz4wcL5WDL97PB](https://blockchain.info/address/1KF8kUVHK42XzgcmJF4Lxz4wcL5WDL97PB)  

As cryptocurrency addicts might say: Proof of Stake and Proof of Work are the best expression of affection, everything else is Fiat.

Find out more about our work at http://n.bitcoin.ninja/