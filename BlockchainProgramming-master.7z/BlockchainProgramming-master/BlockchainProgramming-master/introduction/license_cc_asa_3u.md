## License: CC (ASA 3U) {#license-cc-asa-3u}

You are free to share and adapt, as specified in the Attribution-Share Alike 3.0 Unported (CC BY-SA 3.0).

![](../assets/ccasa3u.png)