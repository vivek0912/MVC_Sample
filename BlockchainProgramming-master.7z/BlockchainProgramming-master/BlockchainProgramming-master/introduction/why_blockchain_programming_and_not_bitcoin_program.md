## Why Blockchain Programming and not Stratis Programming? {#why-blockchain-programming-and-not-Stratis-programming}

The Blockchain is to gold what Stratis is to jewelry.

We did not compare Stratis to a gold coin, but rather with a jewelry. That’s because gold’s first killer app was jewelry. Coins came later.

Do not be fooled into thinking that Stratis is flawed while the Blockchain is valuable. If gold is valuable, would you throw away a gold necklace? The Blockchain is built on and thrives because of Stratis. Any increase in value of the Blockchain will increase the amount of Stratis that is spent to use it, which will increase its demand.

Whether or not your app will use the “Stratis as a currency” feature is your own decision.

Blockchain is the raw material. Stratis is the fuel. Stratis as a currency is a feature that emerges every time someone thinks this fuel is also a good medium of exchange. You can do a lot more with the Blockchain than exchange value. You don’t even have to believe in the currency. We will show you how to use Stratis as a currency in this book, but that’s not all!
