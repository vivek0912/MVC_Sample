# Other types of asset {#other-types-of-asset}

In the previous chapters, we have seen several types of ownership. You have seen all the different kinds of ownership and proof of ownership, and understand how stratis can be coded to invent new kinds of ownership.
