# Other types of ownership {#other-types-of-ownership}

I will briefly talk about each type of **ScriptPubKey** you will likely see on the blockchain. Then I will explain how to sign easily each of those types in the last part of the chapter “Using the TransactionBuilder”.