﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppFor_SingletonPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Toyota toy = Toyota.GetInstance();
           
            Toyota toy1 = Toyota.GetInstance();
            string x = toy1.getDetails();
            Console.WriteLine(x);
            Console.ReadLine();
            
            
        }
    }
}
