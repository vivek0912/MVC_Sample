﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppFor_SingletonPattern
{
    public class Toyota
    {
        private Toyota()
        {

        }
        public static Toyota obj;
        public static Toyota GetInstance()
        {
            if (obj == null)
            {
                obj = new Toyota();

            }
            return obj;

        }
        public string getDetails()
        {
            return "India";
        }
    }
}
