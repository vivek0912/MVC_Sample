﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_ForSample
{
    public class MyClass
    {
        public delegate void MyDelegate(string message);
        public event MyDelegate MyEvent;
        public void RaiseMyEvent(string msg)
        {
            if (MyEvent != null)
                MyEvent(msg);
        }
    }
    class AnonymousMethod
    {
        static void Main(string[] args)
        {
            MyClass myClass1 = new MyClass();
            //myClass1.MyEvent += new MyClass.MyDelegate(myClass1_MyEvent);
            //myClass1.RaiseMyEvent("Hiii");

            //Register event handler as anonymous method.

            myClass1.MyEvent += delegate
            {
                Console.WriteLine("we don't make use of your message in the first handler");
            };
            //Register event handler as anonymous method.
            //here we make use of the incoming arguments.

            myClass1.MyEvent += delegate (string message)
            {
                Console.WriteLine("your message is: {0}", message);
            };
            //the final bracket of the anonymous method must be terminated by a semicolon.

            Console.WriteLine("Enter Your Message");
            string msg = Console.ReadLine();
            //here is we will raise the event.
            myClass1.RaiseMyEvent(msg);
            Console.ReadLine();
        }
        //this method called only by MyDelegate
        public static void myClass1_MyEvent(string message)
        {
            //do some thing to respond to the event here
            Console.WriteLine(message);
        }
    }
}
