﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_ForSample
{
    public delegate double Delegate_Prod(int a, int b);
    public delegate void Delegate_Multicast(int x, int y);
    class abc
    {
        public static double fn_Prodvalues(int val1, int val2)
        {
            return val1 * val2;
        }
        public static void Method1(int x, int y)
        {
            Console.WriteLine("You r in Method 1");
        }

        public static void Method2(int x, int y)
        {
            Console.WriteLine("You r in Method 2");
        }
    }
    class DelegateExample2
    {

        static void Main(string[] args)
        {
            ////Creating the Delegate Instance
            //Delegate_Prod delObj = new Delegate_Prod(abc.fn_Prodvalues);
            //Console.Write("Please Enter Values");
            //int v1 = Int32.Parse(Console.ReadLine());
            //int v2 = Int32.Parse(Console.ReadLine());
            ////use a delegate for processing
            //double res = delObj(v1, v2);
            //Console.WriteLine("Result :" + res);

            //multicast delegate example----------------
            Delegate_Multicast func = new Delegate_Multicast(abc.Method1);
            func += new Delegate_Multicast(abc.Method2);
            func(1, 2);             // Method1 and Method2 are called
            func -= new Delegate_Multicast(abc.Method1);
            func(2, 3);             // Only Method2 is called
            Console.ReadLine();
        }
    }
}
