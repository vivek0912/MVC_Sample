﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_ForSample
{
    public delegate int LambdaDelegate(int a, int y);
    public class TestClass
    {
        public int Multiply(int x, int y)
        {
            return x * y;
        }
    }
    class LambdaExpression
    {
        //public static void Main()
        //{
        //    List<int> list = new List<int>() { 1, 2, 3, 4, 5, 6 };
        //    List<int> evenNumbers = list.FindAll(x => (x % 2) == 0);

        //    foreach (var num in evenNumbers)
        //    {
        //        Console.Write("{0} ", num);
        //    }
        //    Console.WriteLine();
        //    Console.Read();

        //}
        static int Sum(int x, int y) 
        {
            return x + y;
        }
       

        static void Main(string[] args)
        {
            //Func<int, int, int> add = Sum;

            //int result = add(10, 10);
            //LambdaDelegate del =new testDelegate(Sum);
            //Func<int, int, int> Add = (x, y) => x + y;
            //LambdaDelegate del = (x, y) => x + y;

            // int result=del(10, 5);
            TestClass obj = new TestClass();
            
            LambdaDelegate del = new LambdaDelegate(obj.Multiply);

            Console.WriteLine(del(10,9));
            Console.Read();
        }
    }
}
