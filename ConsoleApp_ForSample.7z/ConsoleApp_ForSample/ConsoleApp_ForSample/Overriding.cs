﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_ForSample
{
    //class baseClass
    //{
    //    public virtual void Greetings()
    //    {
    //        Console.WriteLine("baseClass Saying Hello!");
    //    }
    //}
    //class subClass : baseClass
    //{
    //    public override void Greetings()
    //    {
    //       // base.Greetings();
    //        Console.WriteLine("subClass Saying Hello!");
    //    }
    //}

    //class BC
    //{
    //    public void Display()
    //    {
    //        System.Console.WriteLine("BC::Display");
    //    }
    //}

    //class DC : BC
    //{
    //    new public void Display()
    //    {
    //        System.Console.WriteLine("DC::Display");
    //    }
    //}
    class Overriding
    {
        static void Main(string[] args)
        {

            //baseClass obj1 = new subClass();

            //obj1.Greetings();

            //DC obj = new DC();
            //obj.Display();
            ArrayList al = new ArrayList();
            string str = "kiran teja jallepalli";
            int x = 7;
            DateTime d = DateTime.Parse("8-oct-1985");
            al.Add(str);
            al.Add(x);
            al.Add(d);
            //foreach (object o in al)
            //{
            //    Console.WriteLine(o);
            //}

            Hashtable ht = new Hashtable();
            ht.Add("ora", "oracle");
            ht.Add("vb", "vb.net");
            ht.Add("cs", "cs.net");
            ht.Add("asp", "asp.net");

            //foreach (DictionaryEntry dd in ht)
            //{
            //    Console.WriteLine(dd.Key + " " + dd.Value);
            //}

            SortedList sl = new SortedList();
            sl.Add("ora", "oracle");
            sl.Add("vb", "vb.net");
            sl.Add("cs", "cs.net");
            sl.Add("asp", "asp.net");

            //foreach (DictionaryEntry ds in sl)
            //{
            //    Console.WriteLine(ds.Key + " " + ds.Value);
            //}

            Stack stk = new Stack();
            stk.Push("cs.net");
            stk.Push("vb.net");
            stk.Push("asp.net");
            stk.Push("sqlserver");

            stk.Pop();

            //foreach (object o in stk)
            //{
            //    Console.WriteLine(o);
            //}

            Queue q = new Queue();
            q.Enqueue("cs.net");
            q.Enqueue("vb.net");
            q.Enqueue("asp.net");
            q.Enqueue("sqlserver");
            q.Dequeue();

            foreach (object o in q)
            {
                Console.WriteLine(o + "<br>");
            }

            Console.ReadLine();

        }

    }
}
