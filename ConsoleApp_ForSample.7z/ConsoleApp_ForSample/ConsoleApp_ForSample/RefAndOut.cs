﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_ForSample
{
    class RefAndOut
    {
        static void Main(string[] args)
        {
            int i = 0;
            //testmethod(out i);
            //testmethod(ref i);
        }
        //Error  
        private static void TestMethod(out int i,ref int j )
        {
            i = 0;
            Console.WriteLine(i);
        }
        //Error  
        private static void TestMethod(ref int i)
        {
            Console.WriteLine(i);
        }
    }
}
