﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_ForSample
{
    class RefExample
    {
        public void show(int iLocalVar, ref int iRefVar)
        {
            iLocalVar += 10;
            iRefVar+=10;
        }
    }
    class OutExample
    {
        public void show(ref int iRefVar, out int iLocalVar1, out int iLocalVar2)
        {
            iRefVar += 10;
             iLocalVar1 =100;
            iLocalVar2 = 200;
        }
    }
    class RefOutParams
    {
        static void Main(string[] args)
        {
            //int iLocalVar = 10,iRefVar=30;
            //RefExample objRef = new RefExample();
            //objRef.show(iLocalVar, ref iRefVar);
            //Console.WriteLine(String.Format("Local Variable : {0}", iLocalVar));
            //Console.WriteLine(String.Format("Referenced Variable : {0}", iRefVar));


            int iRefVar = 20;
            int iOutVar1 = 0, iOutVar2 =300;
            OutExample objOut = new OutExample();   
            objOut.show(ref iRefVar, out iOutVar1, out iOutVar2);
            Console.WriteLine(String.Format("Referenced Variable: {0}", iRefVar));
            Console.WriteLine(String.Format("Out Parameter Variable 1: {0}", iOutVar1));
            Console.WriteLine(String.Format("Out Parameter Variable 2: {0}", iOutVar2));




            Console.ReadKey();
        }
       
    }
}
