﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_ForSample
{
    class Swaping
    {
        static void Main(string[] args)
        {
            //int a = 4, b = 6;

            //a = a + b;
            //b = a - b;
            //a = a - b;


            // a = a ^ b;
            //a ^= b ^= a ^= b;
            // b ^= a ^= b ^= a;
            //a = a ^ b;
            //b = b ^ a;
            //a = a ^ b;
            //(a, b) = (b, a);
            //Console.WriteLine("swaped value of a is---{0}", a);
            //Console.WriteLine("swaped value of b is---{0}", b);

            var a = 123;
            dynamic b = 123;
            b = b+"aa";
            b += 12344;
            b += "ejeje";
            Console.ReadKey();
        }
    }
}
