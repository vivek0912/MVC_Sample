﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyChat.Chat
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString.Count > 0)
                {
                    lblusername.Text = Request.QueryString["EmpID"];
                    //string empID = "";
                    //string displayName = "";
                    //if (Request.QueryString["EmpID"] == "1075911")
                    //{
                    //    empID = "1075922";
                    //    displayName = "Venkat A";
                    //    lnkbtnhang.Text = "Hangout with ur BUDDY";
                    //}
                    //else if (Request.QueryString["EmpID"] == "1075922")
                    //{
                    //    empID = "1075911";
                    //    displayName = "Vishnu G";
                    //    lnkbtnhang.Text = "Hangout with ur BUDDY";
                    //}
                    //lnkbtnhang.Attributes.Add("onclick", "javascript:return OpenChatWindow('" + empID + "','" + displayName + "')");
                    //lnkbtnhang.Attributes.Add("onclick", "javascript:return OpenChatWindow()");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "SettingSession", "SetSession('" + Session["MemberID"].ToString() + "','" + Session["DisplayName"].ToString() + "');", true);
                }
            }
        }
    }
}