﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyChat.Chat
{
    public partial class UserData : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public class UsersList
        {
            public string UserName = "";
            public string Password = "";
            public string EmpID = "";

            public UsersList(string userName, string password, string empID)
            {
                EmpID = empID;
                UserName = userName;
                Password = password;
            }
        }

        [System.Web.Services.WebMethod]
        public static UsersList[] BindUserInfo()
        {
            List<UsersList> usersList = new List<UsersList>();
            usersList.Add(new UsersList("Vishnu G", "123456", "1075911"));
            usersList.Add(new UsersList("Anil V", "123456", "1217126"));
            usersList.Add(new UsersList("Suresh K", "123456", "1215945"));
            usersList.Add(new UsersList("Sudheer K", "123456", "1071782"));
            return usersList.ToArray();
        }
    }
}