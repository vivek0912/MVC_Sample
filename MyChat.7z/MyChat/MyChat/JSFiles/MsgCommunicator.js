﻿var OpenedWindowsArray = new Array();
var isWindowOpened = "N";

function SetSession(memberID, memberDisplayName, profilePath) {
    localStorage.setItem("LoggedInMemberID", memberID);
    localStorage.setItem("LoggedInMemberDisplayName", memberDisplayName);
    OpenChatWindow();
}

function RegisterEvents(chatHub) {
    var memberID = localStorage.getItem("LoggedInMemberID");
    var memberDisplayName = localStorage.getItem("LoggedInMemberDisplayName");

    chatHub.server.connect(memberID, memberDisplayName);

    chatHub.server.changestatus(localStorage.getItem("LoggedInMemberID"), "A");

    GetStatus(chatHub);
}

function GetStatus(chatHub) {
    try {
        chatHub.server.getstatus();
    } catch (err) {
        alert(err);
    }
}

function SendMessage(senderID, senderName) {

    var message = "";
    var recieverID = "";
    recieverID = $("#hdn_targetid").val();

    var HTMLmessage = document.getElementById('txtMessage').value.toString().replace(/\r\n?/g, '<br/>');
    HTMLmessage = document.getElementById('txtMessage').value.toString().replace(/ /g, '&nbsp;');

    message = HTMLmessage;

    //alert("Sending message..." + message);

    try {
        if (recieverID != "") {
            var msgID = "1";
            var d = new Date();
            var time = d.getDate() + "/" + parseInt(d.getMonth() + 1) + "/" + d.getFullYear() + " " + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();

            var IWannaChat = $.connection.apOnlineChatHub;
            IWannaChat.server.send(msgID, message, recieverID, senderID, senderName, time);

            //document.getElementById('txtMessage' + recieverID + '').value = "";
            document.getElementById('txtMessage').value = "";
        } else {
            alert("Chose a buddy to chat!");
        }
    }
    catch (err) {
        alert(err);
    }
}

function OpenChatWindow() {
    try {
        GetUserInfo();
        return false;
    } catch (err) {
        alert(err);
        return false;
    }
}


//function OpenChatWindow(recieverID, recieverDisplayName) {
//    try {

//        //alert("Opening window...");
//        var senderID = localStorage.getItem("LoggedInMemberID");
//        var senderDisplayName = localStorage.getItem("LoggedInMemberDisplayName");

//        var index = OpenedWindowsArray.indexOf(recieverID);

//        if (index < 0) {

//            $("#" + recieverID).remove();
//            OpenedWindowsArray.push(recieverID);

//            var element = "<div class='wrapper' id='" + recieverID + "'>";
//            element = element + "<div class='container'>";

//            element = element + "<div class='left'>";
//            element = element + "<div class='top'>";
//            element = element + "<input type='text' />";
//            element = element + "<a href='javascript:;' class='search'></a>";
//            element = element + "</div>";
//            element = element + "<ul class='people'>";
//            //element = element + '<li class="person" data-chat="person_' + recieverID + '" OnClick="OnSelectedPerson(this' + ",'" + recieverID + "','" + recieverDisplayName + '\')" >';
//            //element = element + "<span id='lblsender' runat='server' class='name'>" + recieverDisplayName + "</span>";
//            element = element + "</li>";
//            element = element + "</ul>";
//            element = element + "</div>";

//            element = element + "<div class='right'>";
//            element = element + "<div class='top'>";
//            element = element + "<span class='name' id='spn_targetname'></span>";
//            element = element + "</div>";
//            //element = element + "<div class='chat' id='chatbody" + recieverID + "' data-chat='person_" + recieverID + "'></div>";
//            element = element + "<div class='write'>";
//            element = element + "<a href='javascript:;' class='write-link attach'></a>";
//            element = element + '<input id="txtMessage' + recieverID + '"  type="text"  onfocus="var temp_value=this.value;this.value=\'\';this.value=temp_value" onkeypress="if(event.keyCode==13) SendMessage(\'' + recieverID + "','" + senderID + "','" + senderDisplayName + '\');" />';
//            element = element + "<a href='javascript:;' class='write-link smiley'></a><a href='javascript:;' class='write-link send'></a>";
//            element = element + "</div>";
//            element = element + "</div>";

//            element = element + "</div>";
//            element = element + "</div>";

//            $('#homebody').append(element);

//            GetUserInfo();
//        }

//        return false;
//    } catch (err) {
//        alert(err);
//        return false;
//    }
//}

function OnSelectedPerson(obj, recID, recDispName) {
    try {
        //alert(obj.id);
        $(".people li").removeClass("active");
        $(".chat").removeClass("active-chat");
        $("#person_" + recID).addClass("active");
        $("#chatbody" + recID).addClass("active-chat");
        $("#spn_targetname").text(recDispName);
        $("#hdn_targetid").val(recID);
    } catch (err) {
        alert(err);
    }
}


function GetUserInfo() {

    try {

        if (isWindowOpened != "Y") {

            $.ajax({
                type: "POST",
                url: "UserData.aspx/BindUserInfo",
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({}),
                dataType: "json",
                success: function (data) {

                    if (data.d.length > 0) {

                        var element = "";
                        var senderID = localStorage.getItem("LoggedInMemberID");
                        var senderDisplayName = localStorage.getItem("LoggedInMemberDisplayName");
                        //var isWindow = localStorage.getItem("IsWindowOpened");

                        var element = "<div class='wrapper'>";
                        element = element + "<div class='container'>";
                        element = element + "<div class='left'>";
                        element = element + "<div class='top'>";
                        element = element + "<input type='text' value='AP Online Chat Hub' disabled />";
                        element = element + "<a href='javascript:;' class='search'></a>";
                        element = element + "</div>";
                        element = element + "<ul class='people'>";

                        for (var i = 0; i < data.d.length; i++) {

                            if (data.d[i].EmpID != localStorage.getItem("LoggedInMemberID")) {
                                element = element + '<li class="person" id="person_' + data.d[i].EmpID + '" data-chat="person_' + data.d[i].EmpID + '" OnClick="OnSelectedPerson(this' + ",'" + data.d[i].EmpID + "','" + data.d[i].UserName + '\')" >';
                                element = element + "<span class='name'>" + data.d[i].UserName + "</span>";
                                element = element + "</li>";
                            }
                        }

                        element = element + "</ul>";
                        element = element + "</div>";

                        element = element + "<div class='right'>";
                        element = element + "<div class='top'>";
                        element = element + "<span class='name' id='spn_targetname'></span>";
                        element = element + "<input type='hidden' id='hdn_targetid' />";
                        element = element + "</div>";

                        for (var i = 0; i < data.d.length; i++) {

                            if (data.d[i].EmpID != localStorage.getItem("LoggedInMemberID")) {
                                element = element + "<div class='chat' id='chatbody" + data.d[i].EmpID + "' data-chat='person_" + data.d[i].EmpID + "'></div>";
                            }
                        }

                        element = element + "<div class='write'>";
                        element = element + "<a href='javascript:;' class='write-link attach'></a>";
                        element = element + '<input id="txtMessage"  type="text"  onfocus="var temp_value=this.value;this.value=\'\';this.value=temp_value" onkeypress="if(event.keyCode==13) SendMessage(\'' + senderID + "','" + senderDisplayName + '\');" />';
                        element = element + "<a href='javascript:;' class='write-link smiley'></a><a href='javascript:;' class='write-link send'></a>";
                        element = element + "</div>";
                        element = element + "</div>";

                        element = element + "</div>";
                        element = element + "</div>";

                        $('#homebody').append(element);
                        //localStorage.setItem("IsWindowOpened", "Y");
                        isWindowOpened = "Y";
                    }
                    else {
                        alert('No User Found!');
                    }
                },
                failure: function () {
                }
            });
        }
    }
    catch (err) {
        alert('Error');
    }
}


