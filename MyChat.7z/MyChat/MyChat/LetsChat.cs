﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR.Hubs;
using System.Threading;
using System.Data;

/// <summary>
/// Summary description for LetsChat
/// </summary>
[HubName("apOnlineChatHub")]
public class LetsChat : Microsoft.AspNet.SignalR.Hub
{
    //#region Data Members

    static List<UserDetails> ConnectedUsers = new List<UserDetails>();

    //public void send(string msgID, string message, string recieverID, string senderID, string senderName, string session, string time)
    //{
    //    Clients.All.addMessage(msgID, message, recieverID, senderID, senderName, session, time);
    //}
    public void connect(string memberID, string memberName)
    {
        var id = Context.ConnectionId;

        if (ConnectedUsers.Count(x => x.MemberID == memberID) == 0)
        {
            ConnectedUsers.Add(new UserDetails { ConnectionId = id, MemberID = memberID });

            //// send to caller
            //Clients.Caller.onConnected(id, userName, ConnectedUsers, CurrentMessage);

            //// send to all except caller client
            //Clients.AllExcept(id).onNewUserConnected(id, userName);
        }

    }

    public void send(string msgID, string message, string recieverID, string senderID, string senderName, string time)
    {

        //string fromUserId = Context.ConnectionId;

        var toUser = ConnectedUsers.FirstOrDefault(x => x.MemberID == recieverID);
        var fromUser = ConnectedUsers.FirstOrDefault(x => x.MemberID == senderID);

        Clients.Caller.addMessage(msgID, message, recieverID, senderID, senderName, time); //Dt: 27/07/15 Vishnu

        if (toUser == null || fromUser == null)
        {
            Thread.Sleep(3000);
            toUser = ConnectedUsers.FirstOrDefault(x => x.MemberID == recieverID);
            fromUser = ConnectedUsers.FirstOrDefault(x => x.MemberID == senderID);

            //Clients.Caller.addMessageFailed(msgID, message, recieverID, senderID, senderName, session, time);
        }

        if (toUser != null && fromUser != null)
        {

            string toUserID = toUser.ConnectionId;
            string fromUserID = fromUser.ConnectionId;

            // send to 
            Clients.Client(toUserID).addMessage(msgID, message, recieverID, senderID, senderName, time);

            // send to caller user
            //Clients.Caller.addMessage(msgID, message, recieverID, senderID, senderName, session, time); //Dt: 27/07/15 Vishnu
        }
    }

    public void changestatus(string id, string status)
    {
        //DataTable dt = new DataTable();
        //dt = (DataTable)HttpContext.Current.Session["dtMembersList"];
        var toUser = ConnectedUsers.FirstOrDefault(x => x.MemberID == id);
        if (toUser != null)
        {
            string toUserID = toUser.ConnectionId;
            Clients.AllExcept(toUserID).onstatuschanged(id, status);
            //HttpContext.Current.Session["ChatStatus"] = status;
        }

    }

    public void getstatus()
    {
        //DataTable dt = new DataTable();
        //dt = (DataTable)HttpContext.Current.Session["dtMembersList"];
        foreach (var li in ConnectedUsers)
        {
            string toConnID = li.ConnectionId;
            string toMemberID = li.MemberID;
            Clients.AllExcept(toConnID).maintainstatus(toMemberID);
        }

    }

    public override System.Threading.Tasks.Task OnDisconnected() //Dt: 27/07/15 Vishnu
    {
        var item = ConnectedUsers.FirstOrDefault(x => x.ConnectionId == Context.ConnectionId);
        if (item != null)
        {
            ConnectedUsers.Remove(item);
        }

        return base.OnDisconnected();
    }

}
