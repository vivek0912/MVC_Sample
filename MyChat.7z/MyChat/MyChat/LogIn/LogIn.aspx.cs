﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyChat.LogIn
{
    public partial class LogIn : System.Web.UI.Page
    {
        string userName;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

            }
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            if (IsValidUser(txtempid.Value.Trim(), txtpassword.Value.Trim()))
                Response.Redirect("/Chat/Home.aspx?EmpID=" + Session["MemberID"] + " (" + Session["DisplayName"] + ")", false);
            else
                lblinvalid.Visible = true;
            //Response.Redirect("/APOnlineChatHub/Login/Login.aspx", false);
        }

        public bool IsValidUser(string empID, string password)
        {
            List<UsersList> usersList = new List<UsersList>();
            usersList.Add(new UsersList("Vishnu G", "123456", "1075911"));
            usersList.Add(new UsersList("Anil V", "123456", "1217126"));
            usersList.Add(new UsersList("Suresh K", "123456", "1215945"));
            usersList.Add(new UsersList("Sudheer K", "123456", "1071782"));

            var query = from r in usersList.AsEnumerable()
                        where r.EmpID == empID &&
                              r.Password == password
                        select r;

            if (query.ToList().Count > 0)
            {
                Session["MemberID"] = query.ToList()[0].EmpID;
                Session["DisplayName"] = query.ToList()[0].UserName;
                return true;
            }
            else
                return false;
        }

        public class UsersList
        {
            public string UserName = "";
            public string Password = "";
            public string EmpID = "";

            public UsersList(string userName, string password, string empID)
            {
                EmpID = empID;
                UserName = userName;
                Password = password;
            }

        }

    }
}