﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Data;
using System.Xml;
using Org.BouncyCastle.Crypto.Paddings;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Engines;
using Sha2;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Org.BouncyCastle.Crypto;

namespace OTPgeneration
{
    public class EncDecClass
    {
        public byte[] encryptUsingSessionKey(byte[] skey, byte[] data)
        {

            PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(new AesEngine(), new Pkcs7Padding());

            cipher.Init(true, new KeyParameter(skey));

            int outputSize = cipher.GetOutputSize(data.Length);

            byte[] tempOP = new byte[outputSize];
            int processLen = cipher.ProcessBytes(data, 0, data.Length, tempOP, 0);
            int outputLen = cipher.DoFinal(tempOP, processLen);

            byte[] result = new byte[processLen + outputLen];
            Array.Copy(tempOP, 0, result, 0, result.Length);
            return result;

        }

        //public byte[] generateSha256Hash(byte[] message)
        //{
        //    String algorithm = "SHA-256";
        //    String SECURITY_PROVIDER = "BC";


        //    byte[] hash = null;


        //    MessageDigest digest;
        //    try
        //    {
        //        digest = MessageDigest.getInstance(algorithm, SECURITY_PROVIDER);
        //        digest.reset();
        //        hash = digest.digest(message);
        //    }
        //    catch (Exception ex)
        //    {
        //        ex.printStackTrace();
        //    }


        //    return hash;
        //}

        //byte[] Encrypted_SessionKey = encryptUsingPublicKey(Session_Key, ta_xml.Get_UIDAIPublic_Key("uidai_auth_prod.cer"));

        public string Get_UIDAIPublic_Key(string publicKeyFileName)
        {
            string publicKey = "";
            try
            {
                //CertificateFactory certFactory = CertificateFactory.getInstance(CERTIFICATE_TYPE, JCE_PROVIDER);
                //File initialFile = new File("uidai_auth_prod.cer");
                //InputStream targetStream = new FileInputStream(initialFile);
                //X509Certificate cert = (X509Certificate)certFactory.generateCertificate((targetStream));
                //publicKey = cert.GetPublicKey();
                //cert.getNotAfter();

                string Certificate = publicKeyFileName;

                // Load the certificate into an X509Certificate object.
                X509Certificate cert = X509Certificate.CreateFromCertFile(Certificate);

                // Get the value.
                publicKey = cert.GetPublicKeyString();
            }
            catch (Exception e)
            {
                //e.printStackTrace();
                //throw new RuntimeException("Could not intialize encryption module", e);
            }
            finally
            {
            }
            return publicKey;
        }

        //public static byte[] encryptUsingPublicKey(byte[] data,PublicKey publicKey) 
        //{
        //Cipher pkCipher = Cipher.getInstance(ASYMMETRIC_ALGO, JCE_PROVIDER);
        //pkCipher.init(Cipher.ENCRYPT_MODE, publicKey);
        //byte[] encSessionKey = pkCipher.doFinal(data);
        //return encSessionKey;
        //}


    }
}
