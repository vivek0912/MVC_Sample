﻿using System;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace OTPgeneration
{
    public class HashGenerator
    {

        //public static byte[] Hash(byte[] message)
        //{
        //    HashAlgorithm Hasher = new SHA256CryptoServiceProvider();
        //    byte[] strBytes = message;
        //    byte[] strHash = Hasher.ComputeHash(strBytes);
        //    return strHash;
        //}
        public static byte[] Hash(byte[] message)
        {
            var hash = new HMACSHA256();
            return hash.ComputeHash(message);
        }
       



    }

   
}
