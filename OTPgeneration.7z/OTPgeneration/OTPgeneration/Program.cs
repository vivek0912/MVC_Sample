﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Data;
using System.Xml;
using Org.BouncyCastle.Crypto.Paddings;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Engines;
using Sha2;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace OTPgeneration
{
    class Program
    {

        static string OTPAadhar = string.Empty;
        static void Main(string[] args)
        {
            //Program2 obj = new Program2();

            GenerateOTP();
            // Console.WriteLine("GEneration Completed, Please enter OTP");
            //OTPAadhar = Console.ReadLine();
            //Console.WriteLine("Entered OTP:" + OTPAadhar);
            //createOTPPIDxml("OTP", "TS");//pass relevent data here
            encryptPIDXMLENCalongwithSessionKey("306553", "2016-08-29T3:17:32");
        }

        protected static string GenerateOTP()
        {
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(SoapURL);

                //req.Accept = "text/xml";
                req.Method = "POST";
                using (Stream stm = req.GetRequestStream())
                {
                    using (StreamWriter stmw = new StreamWriter(stm))
                    {
                        stmw.Write(OTPSoap());
                    }
                }
                WebResponse response = req.GetResponse();
                Stream responseStream = response.GetResponseStream();
                StreamReader sr = new StreamReader(responseStream);
                string strXML = sr.ReadToEnd();

                DataSet ds = new DataSet("AadhaarDataSet");
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXML);
                ds.ReadXml(new XmlNodeReader(doc));
                if (ds != null)
                {
                    if (ds.Tables[1] != null)
                    {
                        return ds.Tables[1].Rows[0][0].ToString();
                    }
                    else
                    {
                        return "OTP Generation Failed at SRDH";
                    }
                    //lblMessage.Text = strXML;
                }
                return "OTP Generation Failed.Please try again";
                //ObjMain = new SRDHeKYCWS.SRDHeKYCWebServices();
                //return ObjMain.OTPGenerationBySRDHCSCeKYC(UID, AgcName, AgcCode);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected static string OTPSoap()
        {
            try
            {
                string SOAP = soapStart + "<OTPGenerationBySRDHSecuredeKYC xmlns=\"http://services/ecentric/com/xsd\"><uidNum>" + "616681438234" + "</uidNum><agencyName>" + AgenceName + "</agencyName><agencyCode>" + AgencyCode + "</agencyCode></OTPGenerationBySRDHSecuredeKYC>" + soapEnd;
                return SOAP;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        static string SoapURL = "http://ekyc.ap.gov.in/SRDHekycOtpService/services/Services.ServicesSOAP12port_http/";


        static string soapStart = @"<Envelope xmlns=""http://www.w3.org/2003/05/soap-envelope""><Body>";
        public static string AgenceName = "AndhraPradesh/Housing";
        static string AgencyCode = "1/103";
        public static string soapEnd = @"</Body></Envelope>";



        private static void VerifyOTP(byte[] encPID, byte[] encSessionKey, byte[] encHmac)
        {
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(SoapURL);
                //req.ContentType = "text/xml;charset=\"utf-8\"";
                // req.Accept = "text/xml";
                req.Method = "POST";
                using (Stream stm = req.GetRequestStream())
                {
                    using (StreamWriter stmw = new StreamWriter(stm))
                    {
                        stmw.Write(VerifyOTPSoap(encPID, encSessionKey, encHmac));
                    }
                }
                WebResponse response = req.GetResponse();
                Stream responseStream = response.GetResponseStream();
                StreamReader sr = new StreamReader(responseStream);
                string strXML = sr.ReadToEnd();

                DataSet ds = new DataSet("AadhaarDataSet");
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXML);
                ds.ReadXml(new XmlNodeReader(doc));
                if (ds != null)
                {
                    //BindSRDHDate(ds);
                }
                else
                {
                    // ErrMsg = "Something went Wrong. Please try again..";
                    //ScriptManager.RegisterStartupScript(this, GetType(), "ErrorMsg", "AddValidationCustom('" + ErrMsg + "');", true);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        protected static string VerifyOTPSoap(byte[] encPID, byte[] encSessionKey, byte[] encHmac)
        {
            try
            {
                string SOAP = soapStart + "<OTPProcessingBySRDHSecuredeKYC xmlns=\"http://services/ecentric/com/xsd\"><encPID>" + encPID + "</encPID><encSessionKey>" + encSessionKey + "</encSessionKey><encHmac>" + encHmac + "</encHmac><uidNum>" + "536971594141" + "</uidNum><agencyName>" + AgenceName + "</agencyName><agencyCode>" + AgencyCode + "</agencyCode><TimeStamp>" + "2016-10-19T11:50:16" + "</TimeStamp></OTPProcessingBySRDHSecuredeKYC>" + soapEnd;
                return SOAP;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        #region OTP Verification : 25/08/2016  time stamp: 'yyyy-MM-dd'T' HH:MM:SS'
        /// <summary>
        /// Generatesessionkey is for creating random byte[] 
        /// </summary>
        /// <param name="Keynumber"></param>
        /// <returns></returns>
        protected static byte[] GeneratesessionKey(int Keynumber)
        {

            byte[] sessionkey = new byte[Keynumber];
            Random rn = new Random();
            rn.NextBytes(sessionkey);
            return sessionkey;

        }

        /// <summary>
        /// createOTPPIDxml takes OTP and ts as inputs and give xml stirng as output
        /// </summary>
        /// <param name="Keynumber"></param>
        /// <returns></returns>
        protected static string createOTPPIDxml(string OTP, string ts)
        {
            XmlDocument xmlDoc = new XmlDocument();
            XmlNode rootNode = xmlDoc.CreateElement("Pid");
            xmlDoc.AppendChild(rootNode);

            XmlNode userNode = xmlDoc.CreateElement("Pid");
            XmlAttribute attribute = xmlDoc.CreateAttribute("ts");
            attribute.Value = ts;
            userNode.Attributes.Append(attribute);
            attribute = xmlDoc.CreateAttribute("ver");
            attribute.Value = "1.0";
            userNode.Attributes.Append(attribute);
            rootNode.AppendChild(userNode);

            userNode = xmlDoc.CreateElement("Pv");
            attribute = xmlDoc.CreateAttribute("otp");
            attribute.Value = OTP;
            userNode.Attributes.Append(attribute);
            rootNode.AppendChild(userNode);

            return GetXMLAsString(xmlDoc);
        }
        protected static string GetXMLAsString(XmlDocument myxml)
        {

            StringWriter sw = new StringWriter();
            XmlTextWriter tx = new XmlTextWriter(sw);
            myxml.WriteTo(tx);
            string str = sw.ToString();
            return str;
        }
        public static string GetSha256FromString(string strData)
        {
            var message = Encoding.ASCII.GetBytes(strData);
            SHA256Managed hashString = new SHA256Managed();
            string hex = "";

            var hashValue = hashString.ComputeHash(message);
            foreach (byte x in hashValue)
            {
                hex += String.Format("{0:x2}", x);
            }
            return hex;
        }


        protected static void encryptPIDXMLENCalongwithSessionKey(string otp, string tis)
        {
            byte[] sessionkey = GeneratesessionKey(32);//32 is default
            // string pidXMLstirng = createOTPPIDxml("OTP", "ts");//pass relevent data here ###
            string pidXMLstirng = createOTPPIDxml(otp, tis);//pass relevent data here ###

            //encryption of PIDxmlstirng and sessionkey byte array
            byte[] PidxmlByte = Encoding.ASCII.GetBytes(pidXMLstirng);//changing pid xmll into byte[]

            byte[] encPID = Encrypt_Xml_With_Session_Key(sessionkey, pidXMLstirng);//encPID Parameter :1 ###

            byte[] encHmac = HashGenerator.Hash(PidxmlByte);//encHmac parameter:2 ###


            byte[] encryptedSessionKey = EncryptSessionkey(sessionkey, "G:\\Murthhy\\OTPgeneration\\OTPgeneration\\uidai_auth_prod.cer");//encSessionkey parameter:3 ###

            VerifyOTP(encPID, encryptedSessionKey, encHmac);
        }




        protected static byte[] EncryptSessionkey(byte[] textToEncrypt, string key)
        {
            RijndaelManaged rijndaelCipher = new RijndaelManaged();
            rijndaelCipher.Mode = CipherMode.CBC;
            rijndaelCipher.Padding = PaddingMode.PKCS7;

            rijndaelCipher.KeySize = 0x80;
            rijndaelCipher.BlockSize = 0x80;
            byte[] pwdBytes = Encoding.UTF8.GetBytes(key);
            byte[] keyBytes = new byte[0x10];
            int len = pwdBytes.Length;
            if (len > keyBytes.Length)
            {
                len = keyBytes.Length;
            }
            Array.Copy(pwdBytes, keyBytes, len);
            rijndaelCipher.Key = keyBytes;
            rijndaelCipher.IV = keyBytes;
            ICryptoTransform transform = rijndaelCipher.CreateEncryptor();
            byte[] plainText = textToEncrypt;
            return transform.TransformFinalBlock(plainText, 0, plainText.Length);
        }
        //public static byte[] encryptUsingPublicKey(byte[] data,PublicKey publicKey) 
        //{
        // Cipher pkCipher = Cipher.getInstance(ASYMMETRIC_ALGO, JCE_PROVIDER);
        // pkCipher.init(Cipher.ENCRYPT_MODE, publicKey);
        // byte[] encSessionKey = pkCipher.doFinal(data);
        // return encSessionKey;
        //}

        /// <summary>
        /// Encrypt_Xml_With_Session_Key takes sessionkey and Data_To_Encrypt(pid xml string) as inputs and gives
        /// byte[] as output
        /// </summary>
        /// <param name="Keynumber"></param>
        /// <returns></returns>

        public static byte[] Encrypt_Xml_With_Session_Key(byte[] Sessionkey, String Data_To_Encrypt)
        {
            byte[] Data_Bytes = Encoding.ASCII.GetBytes(Data_To_Encrypt);
            PaddedBufferedBlockCipher pb_cipher = new PaddedBufferedBlockCipher(new AesEngine(), new Pkcs7Padding());
            pb_cipher.Init(true, new KeyParameter(Sessionkey));
            int outputSize = pb_cipher.GetOutputSize(Data_Bytes.Length);

            byte[] tempOP = new byte[outputSize];
            int processLen = pb_cipher.ProcessBytes(Data_Bytes, 0, Data_Bytes.Length, tempOP, 0);
            int outputLen;
            try
            {
                outputLen = pb_cipher.DoFinal(tempOP, processLen);
                byte[] Encrypted_Bytes = new byte[processLen + outputLen];
                Array.Copy(tempOP, 0, Encrypted_Bytes, 0, Encrypted_Bytes.Length);
                return Encrypted_Bytes;
            }
            catch (Exception e)
            {
                // TODO Auto-generated catch block

            }

            return null;

        }





        #endregion



    }
}
