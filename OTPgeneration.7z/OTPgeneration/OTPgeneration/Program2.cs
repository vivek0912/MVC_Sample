﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Data;
using System.Xml;
using Org.BouncyCastle.Crypto.Paddings;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Engines;
using Sha2;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Org.BouncyCastle.Crypto;

namespace OTPgeneration
{
    class Program2
    {

        static string OTPAadhar = string.Empty;
        public static byte[] SKEY1;
        // Ta_Xmlclass ta_xml = new Ta_Xmlclass(login_Id, deviceId);

        static void Main1(string[] args)
        {
            //GenerateOTP();
            //Console.WriteLine("GEneration Completed, Please enter OTP");
            //OTPAadhar = Console.ReadLine();
            //Console.WriteLine("Entered OTP:" + OTPAadhar);
            //  createOTPPIDxml("OTP","TS");//pass relevent data here
            encryptPIDXMLENCalongwithSessionKey("327431");//2016-08-29T11:27:49
        }

        protected static string GenerateOTP()
        {
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(SoapURL);

                //req.Accept = "text/xml";
                req.Method = "POST";
                using (Stream stm = req.GetRequestStream())
                {
                    using (StreamWriter stmw = new StreamWriter(stm))
                    {
                        stmw.Write(OTPSoap());
                    }
                }
                WebResponse response = req.GetResponse();
                Stream responseStream = response.GetResponseStream();
                StreamReader sr = new StreamReader(responseStream);
                string strXML = sr.ReadToEnd();

                DataSet ds = new DataSet("AadhaarDataSet");
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXML);
                ds.ReadXml(new XmlNodeReader(doc));
                if (ds != null)
                {
                    if (ds.Tables[1] != null)
                    {
                        return ds.Tables[1].Rows[0][0].ToString();
                    }
                    else
                    {
                        return "OTP Generation Failed at SRDH";
                    }
                    //lblMessage.Text = strXML;
                }
                return "OTP Generation Failed.Please try again";
                //ObjMain = new SRDHeKYCWS.SRDHeKYCWebServices();
                //return ObjMain.OTPGenerationBySRDHCSCeKYC(UID, AgcName, AgcCode);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected static string OTPSoap()
        {
            try
            {
                string SOAP = soapStart + "<OTPGenerationBySRDHSecuredeKYC xmlns=\"http://services/ecentric/com/xsd\"><uidNum>" + "508471277452" + "</uidNum><agencyName>" + AgenceName + "</agencyName><agencyCode>" + AgencyCode + "</agencyCode></OTPGenerationBySRDHSecuredeKYC>" + soapEnd;
                return SOAP;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        static string SoapURL = "http://ekyc.ap.gov.in/SRDHekycOtpService/services/Services.ServicesSOAP12port_http/";

        static string soapStart = @"<Envelope xmlns=""http://www.w3.org/2003/05/soap-envelope""><Body>";
        public static string AgenceName = "AndhraPradesh/Housing";
        static string AgencyCode = "1/103";
        public static string soapEnd = @"</Body>
</Envelope>";

        private static void VerifyOTP(string encPID, string encSessionKey, string encHmac)
        {
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(SoapURL);
                //req.ContentType = "text/xml;charset=\"utf-8\"";
                // req.Accept = "text/xml";
                req.Method = "POST";
                using (Stream stm = req.GetRequestStream())
                {
                    using (StreamWriter stmw = new StreamWriter(stm))
                    {
                        stmw.Write(VerifyOTPSoap(encPID, encSessionKey, encHmac));
                    }
                }
                WebResponse response = req.GetResponse();
                Stream responseStream = response.GetResponseStream();
                StreamReader sr = new StreamReader(responseStream);
                string strXML = sr.ReadToEnd();

                DataSet ds = new DataSet("AadhaarDataSet");
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXML);
                ds.ReadXml(new XmlNodeReader(doc));
                if (ds != null)
                {
                    //  BindSRDHDate(ds);
                }
                else
                {
                    // ErrMsg = "Something went Wrong. Please try again..";
                    //ScriptManager.RegisterStartupScript(this, GetType(), "ErrorMsg", "AddValidationCustom('" + ErrMsg + "');", true);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected static string VerifyOTPSoap(string encPID, string encSessionKey, string encHmac)
        {
            try
            {
                string SOAP = soapStart + "<OTPProcessingBySRDHSecuredeKYC xmlns=\"http://services/ecentric/com/xsd\"><encPID>" + encPID + "</encPID><encSessionKey>" + encSessionKey + "</encSessionKey><encHmac>" + encHmac + "</encHmac><uidNum>" + "508471277452" + "</uidNum><agencyName>" + AgenceName + "</agencyName><agencyCode>" + AgencyCode + "</agencyCode><TimeStamp>" + "2016-08-26T10:17:16" + "</TimeStamp></OTPProcessingBySRDHSecuredeKYC>" + soapEnd;
                return SOAP;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        #region OTP Verification : 25/08/2016  time stamp: 'yyyy-MM-dd'T' HH:MM:SS'
        /// <summary>
        /// Generatesessionkey is for creating random byte[] 
        /// </summary>
        /// <param name="Keynumber"></param>
        /// <returns></returns>
        protected static byte[] GeneratesessionKey(int Keynumber)
        {

            byte[] sessionkey = new byte[Keynumber];
            Random rn = new Random();
            rn.NextBytes(sessionkey);
            return sessionkey;

        }

        /// <summary>
        /// createOTPPIDxml takes OTP and ts as inputs and give xml stirng as output
        /// </summary>
        /// <param name="Keynumber"></param>
        /// <returns></returns>
        protected static string createOTPPIDxml(string OTP, string ts)
        {
            XmlDocument xmlDoc = new XmlDocument();
            XmlNode rootNode = xmlDoc.CreateElement("Pid");
            xmlDoc.AppendChild(rootNode);

            XmlNode userNode = xmlDoc.CreateElement("Pid");
            XmlAttribute attribute = xmlDoc.CreateAttribute("ts");
            attribute.Value = ts;
            userNode.Attributes.Append(attribute);
            attribute = xmlDoc.CreateAttribute("ver");
            attribute.Value = "1.0";
            userNode.Attributes.Append(attribute);
            rootNode.AppendChild(userNode);

            userNode = xmlDoc.CreateElement("Pv");
            attribute = xmlDoc.CreateAttribute("otp");
            attribute.Value = OTP;
            userNode.Attributes.Append(attribute);
            rootNode.AppendChild(userNode);

            return GetXMLAsString(xmlDoc);
        }

        protected static string GetXMLAsString(XmlDocument myxml)
        {

            StringWriter sw = new StringWriter();
            XmlTextWriter tx = new XmlTextWriter(sw);
            myxml.WriteTo(tx);
            string str = sw.ToString();
            return str;
        }

        public static string GetSha256FromString(string strData)
        {
            var message = Encoding.ASCII.GetBytes(strData);
            SHA256Managed hashString = new SHA256Managed();
            string hex = "";

            var hashValue = hashString.ComputeHash(message);
            foreach (byte x in hashValue)
            {
                hex += String.Format("{0:x2}", x);
            }
            return hex;
        }

        protected static void encryptPIDXMLENCalongwithSessionKey(string otp)
        {
            // byte[] Session_Key = ta_xml.Generate_Session_Key(32);
            //byte[] sessionkey = GeneratesessionKey(32);//32 is default
            // string pidXMLstirng = createOTPPIDxml("OTP", "ts");//pass relevent data here ###
            //string pidXMLstirng = createOTPPIDxml(otp, "2016-08-26T10:17:16");//pass relevent data here ###

            //encryption of PIDxmlstirng and sessionkey byte array
            string original = File.ReadAllText("G:\\Murthhy\\OTPgeneration\\OTPgeneration\\pid.xml").ToString();
            byte[] PidxmlByte = Encoding.ASCII.GetBytes(original);//changing pid xmll into byte[]

            //byte[] encPID = Encrypt_Xml_With_Session_Key(sessionkey, pidXMLstirng);//encPID Parameter :1 ###
            //EncDecClass obj = new EncDecClass();
            //byte[] encPID = encryptUsingSessionKey(sessionkey, PidxmlByte);//encPID Parameter :1 ###

            //byte[] Hmac = HashGenerator.Hash(PidxmlByte);//encHmac parameter:2 ###
            //byte[] encHmac = encryptUsingSessionKey(sessionkey, Hmac);
            //byte[] encryptedSessionKey = EncryptSessionkey(sessionkey, "G:\\Murthhy\\OTPgeneration\\OTPgeneration\\uidai_auth_prod.cer");//encSessionkey parameter:3 ###

            //string certPath = "G:\\Murthhy\\OTPgeneration\\OTPgeneration\\uidai_auth_prod.cer";
            //string pk = obj.Get_UIDAIPublic_Key(certPath);

            //byte[] encryptedSessionKey = EncryptSessionkey(sessionkey, pk);
            //byte[] encryptedSessionKey = EncryptSessionkey(sessionkey, "G:\\Murthhy\\OTPgeneration\\OTPgeneration\\uidai_auth_prod.cer");

            //string original = pidXMLstirng;

            string skey = SSKEY();
            byte[] Hmac1;
            string getHashSha256from_Original = GetSHA256(original);
            RijndaelManaged myRijndael = new RijndaelManaged();
            Hmac1 = EncryptStringToBytes_Aes(getHashSha256from_Original, SKEY1, myRijndael.IV);
            string Hmac = System.Convert.ToBase64String(Hmac1);
            byte[] encrypted;
            encrypted = EncryptStringToBytes_Aes(original, SKEY1, myRijndael.IV);
            string encPID2 = System.Convert.ToBase64String(encrypted);

            VerifyOTP(encPID2, skey, Hmac);
        }

        static byte[] EncryptStringToBytes_Aes(string plainText, byte[] Key, byte[] IV)
        {
            // Check arguments. 
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("Key");
            byte[] encrypted;

            using (AesManaged aesAlg = new AesManaged())
            {

                aesAlg.Key = Key;
                aesAlg.IV = IV;
                aesAlg.Mode = CipherMode.CBC;
                aesAlg.Padding = PaddingMode.PKCS7;
                aesAlg.KeySize = 256;
                aesAlg.BlockSize = 128;
                // Create a decrytor to perform the stream transform.
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for encryption. 
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            return encrypted;
        }

        public static string SSKEY()
        {
            AesManaged sessionKey = new AesManaged();

            sessionKey.KeySize = 256;
            byte[] encryptedtext;
            SKEY1 = sessionKey.Key;
            byte[] SkeyIV = sessionKey.IV;
            sessionKey.GenerateKey();

            var str = System.Text.Encoding.Default.GetString(SKEY1);

            X509Store store = new X509Store(StoreLocation.CurrentUser);
            store.Open(OpenFlags.ReadOnly);
            X509Certificate2Collection certcollection = store.Certificates;
            X509Certificate2 x509 = new X509Certificate2("G:\\Murthhy\\OTPgeneration\\OTPgeneration\\uidai_auth_prod.cer");
            RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)x509.PublicKey.Key;

            byte[] bytestoEncrypt = ASCIIEncoding.ASCII.GetBytes(str);
            byte[] encryptedBytes = rsa.Encrypt(bytestoEncrypt, false);

            return Convert.ToBase64String(encryptedBytes);

        }

        public static byte[] encryptUsingSessionKey(byte[] data, byte[] skey)
        {
            PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(new AesEngine(), new Pkcs7Padding());

            cipher.Init(true, new KeyParameter(skey));

            int outputSize = cipher.GetOutputSize(data.Length);

            byte[] tempOP = new byte[outputSize];
            int processLen = cipher.ProcessBytes(data, 0, data.Length, tempOP, 0);
            int outputLen = cipher.DoFinal(tempOP, processLen);

            byte[] result = new byte[processLen + outputLen];
            tempOP.CopyTo(result, 0);
            return result;
        }

        public static string GetSHA256(string text)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(text);
            using (SHA256Managed algorithm = new SHA256Managed())
            {
                byte[] buffer2 = algorithm.TransformFinalBlock(bytes, 0, bytes.Length);
                byte[] hash = algorithm.Hash;
                return Convert.ToBase64String(algorithm.Hash);
            }
        }

        protected static byte[] EncryptSessionkey(byte[] textToEncrypt, string key)
        {

            RijndaelManaged rijndaelCipher = new RijndaelManaged();
            rijndaelCipher.Mode = CipherMode.CBC;
            rijndaelCipher.Padding = PaddingMode.PKCS7;

            rijndaelCipher.KeySize = 0x80;
            rijndaelCipher.BlockSize = 0x80;
            byte[] pwdBytes = Encoding.UTF8.GetBytes(key);
            byte[] keyBytes = new byte[0x10];
            int len = pwdBytes.Length;
            if (len > keyBytes.Length)
            {
                len = keyBytes.Length;
            }
            Array.Copy(pwdBytes, keyBytes, len);
            rijndaelCipher.Key = keyBytes;
            rijndaelCipher.IV = keyBytes;
            ICryptoTransform transform = rijndaelCipher.CreateEncryptor();
            byte[] plainText = textToEncrypt;
            return transform.TransformFinalBlock(plainText, 0, plainText.Length);
        }

        //public static byte[] encryptUsingPublicKey(byte[] data, PublicKey publicKey)
        //{
        //    Cipher pkCipher = Cipher.getInstance(ASYMMETRIC_ALGO, JCE_PROVIDER);
        //    pkCipher.init(Cipher.ENCRYPT_MODE, publicKey);
        //    byte[] encSessionKey = pkCipher.doFinal(data);
        //    return encSessionKey;
        //}

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        /// <summary>
        /// Encrypt_Xml_With_Session_Key takes sessionkey and Data_To_Encrypt(pid xml string) as inputs and gives
        /// byte[] as output
        /// </summary>
        /// <param name="Keynumber"></param>
        /// <returns></returns>

        public static byte[] Encrypt_Xml_With_Session_Key(byte[] Sessionkey, String Data_To_Encrypt)
        {
            byte[] Data_Bytes = Encoding.ASCII.GetBytes(Data_To_Encrypt);
            PaddedBufferedBlockCipher pb_cipher = new PaddedBufferedBlockCipher(new AesEngine(), new Pkcs7Padding());
            pb_cipher.Init(true, new KeyParameter(Sessionkey));
            int outputSize = pb_cipher.GetOutputSize(Data_Bytes.Length);

            byte[] tempOP = new byte[outputSize];
            int processLen = pb_cipher.ProcessBytes(Data_Bytes, 0, Data_Bytes.Length, tempOP, 0);
            int outputLen;
            try
            {
                outputLen = pb_cipher.DoFinal(tempOP, processLen);
                byte[] Encrypted_Bytes = new byte[processLen + outputLen];
                Array.Copy(tempOP, 0, Encrypted_Bytes, 0, Encrypted_Bytes.Length);
                return Encrypted_Bytes;
            }
            catch (Exception e)
            {
                // TODO Auto-generated catch block

            }

            return null;

        }

        //public static byte[] Encrypt_Xml_With_Session_Key(byte[] Sessionkey, String Data_To_Encrypt)
        //{
        //    byte[] Data_Bytes = Data_To_Encrypt.getBytes();
        //    PaddedBufferedBlockCipher pb_cipher = new PaddedBufferedBlockCipher(new AESEngine(), new PKCS7Padding());
        //    pb_cipher.init(true, new KeyParameter(Sessionkey));
        //    int outputSize = pb_cipher.getOutputSize(Data_Bytes.length);

        //    byte[] tempOP = new byte[outputSize];
        //    int processLen = pb_cipher.processBytes(Data_Bytes, 0, Data_Bytes.length, tempOP, 0);
        //    int outputLen;
        //    try
        //    {
        //        outputLen = pb_cipher.doFinal(tempOP, processLen);
        //        byte[] Encrypted_Bytes = new byte[processLen + outputLen];
        //        System.arraycopy(tempOP, 0, Encrypted_Bytes, 0, Encrypted_Bytes.length);
        //        return Encrypted_Bytes;
        //    }
        //    catch (DataLengthException e)
        //    {
        //        // TODO Auto-generated catch block
        //        e.printStackTrace();
        //    }
        //    catch (IllegalStateException e)
        //    {
        //        // TODO Auto-generated catch block
        //        e.printStackTrace();
        //    }
        //    catch (InvalidCipherTextException e)
        //    {
        //        // TODO Auto-generated catch block
        //        e.printStackTrace();
        //    }
        //    return null;
        //}

        //public class HashGenerator
        //{

        //    public byte[] generateSha256Hash(byte[] message)
        //    {
        //        String algorithm = "SHA-256";
        //        String SECURITY_PROVIDER = "BC";

        //        byte[] hash = null;

        //        MessageDigest digest;
        //        try
        //        {
        //            digest = MessageDigest.getInstance(algorithm, SECURITY_PROVIDER);
        //            digest.reset();
        //            hash = digest.digest(message);
        //        }
        //        catch (Exception e)
        //        {
        //            e.printStackTrace();
        //        }

        //        return hash;
        //    }

        //}

        #endregion

    }
}
