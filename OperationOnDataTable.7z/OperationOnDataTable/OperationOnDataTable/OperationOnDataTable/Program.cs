﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data; 
namespace OperationOnDataTable
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create Datatable instance
            DataTable tempTable = new DataTable();
           
            // Add columns in DataTable
            tempTable.Columns.Add("ID");
            tempTable.Columns.Add("NAME");

            // Add New Row in dataTable
            DataRow newrow = tempTable.NewRow();
            newrow[0] = 0;
            newrow[1] = "Avinash";
            tempTable.Rows.Add(newrow);
            // Add Another New Row in dataTable
            newrow = tempTable.NewRow();
            newrow[0] = 1;
            newrow[1] = "Kavita";
            tempTable.Rows.Add(newrow);

            //Now table is ready 
            Console.WriteLine("Origenal table");
            for (int i = 0; i < tempTable.Rows.Count; i++)
            {
                Console.WriteLine(tempTable.Rows[i][0].ToString()+"--->"+ tempTable.Rows[i][1].ToString());
            
            }

            // if you want edit data form TataTable
            Console.WriteLine("\nModified table");
            for (int i = 0; i < tempTable.Rows.Count; i++)
            {
                if (tempTable.Rows[i][1].ToString()=="Kavita")
                {
                    tempTable.Rows[i][1]="gare";
                }
                Console.WriteLine(tempTable.Rows[i][0].ToString() + "--->" + tempTable.Rows[i][1].ToString());

            }


            // if you want delete row form TataTable
            Console.WriteLine("\nAfter deleting row from table");
            for (int i = 0; i < tempTable.Rows.Count; i++)
            {
                if (tempTable.Rows[i][1].ToString() == "gare")
                {
                    tempTable.Rows[i].Delete();
                 
                }
            }
            for (int i = 0; i < tempTable.Rows.Count; i++)
            {
               
                Console.WriteLine(tempTable.Rows[i][0].ToString() + "--->" + tempTable.Rows[i][1].ToString());

            }
            


            Console.ReadLine();

        }
    }
}
