﻿(function () {
    angular.module("demoApp", []);
}());